import { useState, useRef, DragEvent } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  Copy, 
  ArrowLeft,
  Shield,
  Loader2,
  Share2
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { copyToClipboard } from "../lib/clipboard";

interface IPFSUploadPageProps {
  onBack?: () => void;
}

export function IPFSUploadPage({ onBack }: IPFSUploadPageProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [ipfsCID, setIpfsCID] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      setSelectedFile(file);
      toast.success(`File "${file.name}" ready to upload`);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setSelectedFile(file);
      toast.success(`File "${file.name}" ready to upload`);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  const handleUpload = () => {
    if (!selectedFile) {
      toast.error("Please select a file first");
      return;
    }

    setIsUploading(true);

    // Simulate IPFS upload with a delay
    setTimeout(() => {
      // Generate a mock IPFS CID (Content Identifier)
      const mockCID = `Qm${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
      setIpfsCID(mockCID);
      setUploadComplete(true);
      setIsUploading(false);
      toast.success("Document uploaded to IPFS successfully!");
    }, 2500);
  };

  const handleCopyCID = () => {
    copyToClipboard(ipfsCID).then((success) => {
      if (success) {
        toast.success("IPFS CID copied to clipboard!");
      } else {
        toast.error("Failed to copy to clipboard");
      }
    });
  };

  const handleCopyGatewayURL = () => {
    const gatewayURL = `https://ipfs.io/ipfs/${ipfsCID}`;
    copyToClipboard(gatewayURL).then((success) => {
      if (success) {
        toast.success("Gateway URL copied to clipboard!");
      } else {
        toast.error("Failed to copy to clipboard");
      }
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const resetUpload = () => {
    setSelectedFile(null);
    setUploadComplete(false);
    setIpfsCID("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Navigation Header */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-600" />
              <span className="tracking-tight" style={{ fontSize: '1.25rem', fontWeight: '600' }}>
                IdentityVault
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12 max-w-4xl">
        {/* Back Button */}
        {onBack && (
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        )}

        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Upload className="w-6 h-6 text-purple-600" />
            </div>
            <h1 style={{ fontSize: '2.25rem', fontWeight: '700' }} className="text-gray-900">
              Upload Document to IPFS
            </h1>
          </div>
          <p className="text-gray-600 ml-15" style={{ fontSize: '1.125rem' }}>
            Store your verifiable credentials or documents on the decentralized web
          </p>
        </div>

        {!uploadComplete ? (
          <>
            {/* Drag & Drop Area */}
            <Card className="mb-6 border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors">
              <CardContent className="p-0">
                <div
                  onDragEnter={handleDragEnter}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={handleBrowseClick}
                  className={`p-12 cursor-pointer transition-all ${
                    isDragging
                      ? 'bg-purple-50 border-purple-400'
                      : selectedFile
                      ? 'bg-green-50'
                      : 'bg-white hover:bg-gray-50'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileSelect}
                    className="hidden"
                    accept=".json,.pdf,.png,.jpg,.jpeg,.txt"
                  />

                  <div className="flex flex-col items-center text-center space-y-4">
                    {selectedFile ? (
                      <>
                        <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center">
                          <FileText className="w-8 h-8 text-green-600" />
                        </div>
                        <div>
                          <p style={{ fontSize: '1.125rem', fontWeight: '600' }} className="text-gray-900 mb-1">
                            {selectedFile.name}
                          </p>
                          <p style={{ fontSize: '0.875rem' }} className="text-gray-600">
                            {formatFileSize(selectedFile.size)} • Ready to upload
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedFile(null);
                          }}
                          className="text-gray-600 hover:text-gray-900"
                        >
                          Change file
                        </Button>
                      </>
                    ) : (
                      <>
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-colors ${
                          isDragging ? 'bg-purple-200' : 'bg-gray-100'
                        }`}>
                          <Upload className={`w-8 h-8 ${isDragging ? 'text-purple-600' : 'text-gray-400'}`} />
                        </div>
                        <div>
                          <p style={{ fontSize: '1.125rem', fontWeight: '600' }} className="text-gray-900 mb-2">
                            {isDragging ? 'Drop your file here' : 'Drag and drop your file here'}
                          </p>
                          <p style={{ fontSize: '0.875rem' }} className="text-gray-600 mb-3">
                            or click to browse from your device
                          </p>
                          <p style={{ fontSize: '0.75rem' }} className="text-gray-500">
                            Supported formats: JSON, PDF, PNG, JPG, TXT
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Upload Button */}
            <div className="flex justify-center mb-8">
              <Button
                size="lg"
                onClick={handleUpload}
                disabled={!selectedFile || isUploading}
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 disabled:opacity-50"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Uploading to IPFS...
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 mr-2" />
                    Upload Document
                  </>
                )}
              </Button>
            </div>

            {/* IPFS Info Card */}
            <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <Share2 className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-purple-900 mb-2">
                      Why IPFS?
                    </p>
                    <ul className="space-y-1 text-purple-700" style={{ fontSize: '0.875rem' }}>
                      <li>• <strong>Decentralized:</strong> Your files are distributed across a peer-to-peer network</li>
                      <li>• <strong>Permanent:</strong> Content-addressed storage ensures your data persists</li>
                      <li>• <strong>Verifiable:</strong> Each file gets a unique CID that proves authenticity</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          /* Success Section */
          <div className="space-y-6">
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-7 h-7 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }} className="text-green-900 mb-2">
                      Upload Successful!
                    </h2>
                    <p className="text-green-700" style={{ fontSize: '1rem' }}>
                      Your document has been securely uploaded to IPFS and is now accessible via the decentralized network.
                    </p>
                  </div>
                </div>

                {/* File Info */}
                <div className="bg-white rounded-lg p-4 border border-green-200 mb-4">
                  <div className="flex items-center gap-3 mb-3">
                    <FileText className="w-5 h-5 text-gray-600" />
                    <div>
                      <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900">
                        {selectedFile?.name}
                      </p>
                      <p style={{ fontSize: '0.75rem' }} className="text-gray-600">
                        {selectedFile && formatFileSize(selectedFile.size)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* IPFS CID Display */}
                <div className="bg-white rounded-lg p-4 border border-green-200 mb-4">
                  <label className="text-green-900 mb-2 block" style={{ fontSize: '0.875rem', fontWeight: '600' }}>
                    IPFS Content Identifier (CID):
                  </label>
                  <div className="flex items-center gap-2 mb-3">
                    <code 
                      className="flex-1 text-gray-900 bg-gray-50 px-3 py-2 rounded border border-gray-200 overflow-x-auto"
                      style={{ fontSize: '0.875rem', fontWeight: '500' }}
                    >
                      {ipfsCID}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleCopyCID}
                      className="flex-shrink-0 border-green-300 hover:bg-green-50"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>

                  <label className="text-green-900 mb-2 block" style={{ fontSize: '0.875rem', fontWeight: '600' }}>
                    Gateway URL:
                  </label>
                  <div className="flex items-center gap-2">
                    <code 
                      className="flex-1 text-blue-600 bg-gray-50 px-3 py-2 rounded border border-gray-200 overflow-x-auto"
                      style={{ fontSize: '0.875rem' }}
                    >
                      https://ipfs.io/ipfs/{ipfsCID}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleCopyGatewayURL}
                      className="flex-shrink-0 border-green-300 hover:bg-green-50"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    variant="default"
                    className="bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => window.open(`https://ipfs.io/ipfs/${ipfsCID}`, '_blank')}
                  >
                    View on IPFS
                  </Button>
                  <Button
                    variant="outline"
                    className="border-green-300 hover:bg-green-50"
                    onClick={resetUpload}
                  >
                    Upload Another File
                  </Button>
                  {onBack && (
                    <Button
                      variant="ghost"
                      onClick={onBack}
                      className="text-gray-600"
                    >
                      Back to Dashboard
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Next Steps Info */}
            <div className="grid md:grid-cols-2 gap-4">
              <Card className="bg-white border-gray-200">
                <CardContent className="p-6">
                  <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900 mb-2">
                    📌 Save Your CID
                  </p>
                  <p style={{ fontSize: '0.875rem' }} className="text-gray-600">
                    Store this CID to access your document anytime from any IPFS gateway
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-gray-200">
                <CardContent className="p-6">
                  <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900 mb-2">
                    🔗 Share Securely
                  </p>
                  <p style={{ fontSize: '0.875rem' }} className="text-gray-600">
                    Share the CID or gateway URL with anyone who needs to verify your credential
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}