import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { CheckCircle2, Wallet, Key, Copy, ArrowLeft } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { copyToClipboard } from "../lib/clipboard";

interface DIDCreationFormProps {
  onBack?: () => void;
  onDIDCreated?: (did: string) => void;
}

export function DIDCreationForm({ onBack, onDIDCreated }: DIDCreationFormProps) {
  const [walletConnected, setWalletConnected] = useState(false);
  const [didGenerated, setDidGenerated] = useState(false);
  const [generatedDID, setGeneratedDID] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const handleConnectWallet = () => {
    // Placeholder logic for wallet connection
    setWalletConnected(true);
    toast.success("Wallet connected successfully!");
  };

  const handleGenerateDID = () => {
    // Simulate DID generation
    setIsGenerating(true);
    
    setTimeout(() => {
      // Generate a mock DID (following W3C DID standard format)
      const mockDID = `did:ethr:0x${Math.random().toString(16).substr(2, 40)}`;
      setGeneratedDID(mockDID);
      setDidGenerated(true);
      setIsGenerating(false);
      if (onDIDCreated) {
        onDIDCreated(mockDID);
      }
    }, 1500);
  };

  const handleCopyDID = () => {
    copyToClipboard(generatedDID).then((success) => {
      if (success) {
        toast.success("DID copied to clipboard!");
      } else {
        toast.error("Failed to copy to clipboard");
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-2xl">
        {/* Back Button */}
        {onBack && (
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        )}

        <Card className="shadow-2xl border-0">
          <CardHeader className="space-y-3 pb-8">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Key className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <CardTitle style={{ fontSize: '1.875rem' }}>
                  Create Your Decentralized ID
                </CardTitle>
                <CardDescription style={{ fontSize: '1rem' }} className="mt-1">
                  Follow the steps below to generate your secure digital identity
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-8">
            {/* Step 1: Connect Wallet */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div 
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    walletConnected ? 'bg-green-100' : 'bg-blue-100'
                  }`}
                >
                  {walletConnected ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <span className="text-blue-600" style={{ fontWeight: '600' }}>1</span>
                  )}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600' }}>
                    Connect Your Wallet
                  </h3>
                  <p className="text-gray-600" style={{ fontSize: '0.875rem' }}>
                    Connect your Web3 wallet to proceed with DID creation
                  </p>
                </div>
              </div>

              <div className="pl-11">
                <Button
                  size="lg"
                  variant={walletConnected ? "outline" : "default"}
                  onClick={handleConnectWallet}
                  disabled={walletConnected}
                  className={
                    walletConnected
                      ? "border-green-200 text-green-700 bg-green-50"
                      : "bg-blue-600 hover:bg-blue-700 text-white"
                  }
                >
                  <Wallet className="w-5 h-5 mr-2" />
                  {walletConnected ? "Wallet Connected" : "Connect Wallet"}
                </Button>
              </div>
            </div>

            {/* Divider */}
            <div className="border-t border-gray-200"></div>

            {/* Step 2: Generate DID */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div 
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    didGenerated ? 'bg-green-100' : 'bg-gray-100'
                  }`}
                >
                  {didGenerated ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <span 
                      className={walletConnected ? 'text-blue-600' : 'text-gray-400'} 
                      style={{ fontWeight: '600' }}
                    >
                      2
                    </span>
                  )}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '600' }}>
                    Generate Your DID
                  </h3>
                  <p className="text-gray-600" style={{ fontSize: '0.875rem' }}>
                    Create your unique decentralized identifier
                  </p>
                </div>
              </div>

              <div className="pl-11">
                <Button
                  size="lg"
                  onClick={handleGenerateDID}
                  disabled={!walletConnected || didGenerated || isGenerating}
                  className="bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50"
                >
                  <Key className="w-5 h-5 mr-2" />
                  {isGenerating ? "Generating..." : "Generate DID"}
                </Button>
              </div>
            </div>

            {/* Success Message */}
            {didGenerated && (
              <div className="mt-8 p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h4 style={{ fontSize: '1.125rem', fontWeight: '600' }} className="text-green-900">
                      Success! Your DID has been created and secured.
                    </h4>
                    <p className="text-green-700 mt-1" style={{ fontSize: '0.875rem' }}>
                      Your decentralized identifier is ready to use. Keep it safe and share it as needed.
                    </p>
                  </div>
                </div>

                {/* Generated DID Display */}
                <div className="bg-white rounded-lg p-4 border border-green-200">
                  <label className="text-green-900 mb-2 block" style={{ fontSize: '0.875rem', fontWeight: '600' }}>
                    Your Decentralized ID:
                  </label>
                  <div className="flex items-center gap-2">
                    <code 
                      className="flex-1 text-gray-800 bg-gray-50 px-3 py-2 rounded border border-gray-200 overflow-x-auto"
                      style={{ fontSize: '0.875rem' }}
                    >
                      {generatedDID}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleCopyDID}
                      className="flex-shrink-0 border-green-200 hover:bg-green-50"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Next Steps */}
                <div className="pt-4 flex gap-3">
                  <Button
                    variant="default"
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    Download Credentials
                  </Button>
                  <Button
                    variant="outline"
                    className="border-green-300 hover:bg-green-50"
                    onClick={() => onDIDCreated && onDIDCreated(generatedDID)}
                  >
                    View Dashboard
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-4 mt-8">
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900">
              🔐 Secure
            </p>
            <p style={{ fontSize: '0.75rem' }} className="text-gray-600 mt-1">
              Encrypted and stored on blockchain
            </p>
          </div>
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900">
              🌐 Portable
            </p>
            <p style={{ fontSize: '0.75rem' }} className="text-gray-600 mt-1">
              Use across any DID-compatible service
            </p>
          </div>
          <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900">
              👤 Your Control
            </p>
            <p style={{ fontSize: '0.75rem' }} className="text-gray-600 mt-1">
              You own and manage your identity
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}