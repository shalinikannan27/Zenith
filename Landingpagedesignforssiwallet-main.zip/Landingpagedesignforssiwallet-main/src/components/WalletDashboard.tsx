import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { 
  Shield, 
  Copy, 
  Upload, 
  FolderOpen, 
  CheckCircle, 
  Menu,
  LogOut
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { copyToClipboard } from "../lib/clipboard";

interface WalletDashboardProps {
  did?: string;
  onLogout?: () => void;
  onNavigateToUpload?: () => void;
  onNavigateToVerify?: () => void;
}

export function WalletDashboard({ 
  did = "did:web:example:123456789abcdef", 
  onLogout,
  onNavigateToUpload,
  onNavigateToVerify
}: WalletDashboardProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleCopyDID = () => {
    copyToClipboard(did).then((success) => {
      if (success) {
        toast.success("DID copied to clipboard!");
      } else {
        toast.error("Failed to copy to clipboard");
      }
    });
  };

  const navigationCards = [
    {
      title: "Upload Credential",
      description: "Receive and store new verifiable credentials",
      icon: Upload,
      color: "blue",
      action: () => onNavigateToUpload ? onNavigateToUpload() : toast.info("Upload credential feature coming soon!")
    },
    {
      title: "My Credentials",
      description: "View and manage your stored credentials",
      icon: FolderOpen,
      color: "purple",
      action: () => toast.info("Credentials view coming soon!")
    },
    {
      title: "Verify",
      description: "Share proofs and verify your identity",
      icon: CheckCircle,
      color: "green",
      action: () => onNavigateToVerify ? onNavigateToVerify() : toast.info("Verification feature coming soon!")
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Navigation Header */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-600" />
              <span className="tracking-tight" style={{ fontSize: '1.25rem', fontWeight: '600' }}>
                IdentityVault
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-4">
              <Button variant="ghost" className="text-gray-600">
                Dashboard
              </Button>
              <Button variant="ghost" className="text-gray-600">
                Settings
              </Button>
              {onLogout && (
                <Button 
                  variant="outline" 
                  onClick={onLogout}
                  className="border-gray-300"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <Button 
              variant="ghost" 
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden mt-4 py-4 space-y-2 border-t border-gray-200">
              <Button variant="ghost" className="w-full justify-start text-gray-600">
                Dashboard
              </Button>
              <Button variant="ghost" className="w-full justify-start text-gray-600">
                Settings
              </Button>
              {onLogout && (
                <Button 
                  variant="outline" 
                  onClick={onLogout}
                  className="w-full justify-start border-gray-300"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              )}
            </div>
          )}
        </div>
      </nav>

      {/* Main Dashboard Content */}
      <main className="container mx-auto px-6 py-12 max-w-6xl">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 style={{ fontSize: '2.25rem', fontWeight: '700' }} className="text-gray-900 mb-2">
            Welcome to Your Wallet
          </h1>
          <p className="text-gray-600" style={{ fontSize: '1.125rem' }}>
            Manage your decentralized identity and credentials securely
          </p>
        </div>

        {/* DID Display Card */}
        <Card className="mb-12 border-2 border-blue-100 bg-gradient-to-br from-white to-blue-50/30">
          <CardContent className="p-8">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <label 
                  className="text-blue-900 mb-3 block" 
                  style={{ fontSize: '0.875rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.05em' }}
                >
                  Your Decentralized ID
                </label>
                <div className="flex items-center gap-3">
                  <code 
                    className="flex-1 text-gray-900 bg-white px-4 py-3 rounded-lg border border-blue-200 overflow-x-auto"
                    style={{ fontSize: '1rem', fontWeight: '500' }}
                  >
                    {did}
                  </code>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={handleCopyDID}
                    className="flex-shrink-0 border-blue-300 hover:bg-blue-50 hover:border-blue-400"
                  >
                    <Copy className="w-5 h-5 text-blue-600" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions Section */}
        <div className="mb-8">
          <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }} className="text-gray-900 mb-6">
            Quick Actions
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {navigationCards.map((card, index) => {
              const Icon = card.icon;
              const colorClasses = {
                blue: {
                  bg: 'bg-blue-100',
                  text: 'text-blue-600',
                  hover: 'hover:border-blue-300',
                  gradient: 'from-blue-50/50'
                },
                purple: {
                  bg: 'bg-purple-100',
                  text: 'text-purple-600',
                  hover: 'hover:border-purple-300',
                  gradient: 'from-purple-50/50'
                },
                green: {
                  bg: 'bg-green-100',
                  text: 'text-green-600',
                  hover: 'hover:border-green-300',
                  gradient: 'from-green-50/50'
                }
              }[card.color];

              return (
                <Card
                  key={index}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-xl border-2 border-gray-100 ${colorClasses.hover} bg-gradient-to-br from-white ${colorClasses.gradient}`}
                  onClick={card.action}
                >
                  <CardContent className="p-8">
                    <div className="space-y-4">
                      <div className={`w-14 h-14 ${colorClasses.bg} rounded-2xl flex items-center justify-center`}>
                        <Icon className={`w-7 h-7 ${colorClasses.text}`} />
                      </div>
                      
                      <div>
                        <h3 
                          style={{ fontSize: '1.25rem', fontWeight: '600' }} 
                          className="text-gray-900 mb-2"
                        >
                          {card.title}
                        </h3>
                        <p 
                          style={{ fontSize: '0.875rem' }} 
                          className="text-gray-600 leading-relaxed"
                        >
                          {card.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid sm:grid-cols-3 gap-6 mt-12">
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-600 mb-1">
              Total Credentials
            </p>
            <p style={{ fontSize: '2rem', fontWeight: '700' }} className="text-gray-900">
              0
            </p>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-600 mb-1">
              Verifications Shared
            </p>
            <p style={{ fontSize: '2rem', fontWeight: '700' }} className="text-gray-900">
              0
            </p>
          </div>
          
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-600 mb-1">
              Account Status
            </p>
            <div className="flex items-center gap-2 mt-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <p style={{ fontSize: '1rem', fontWeight: '600' }} className="text-green-700">
                Active
              </p>
            </div>
          </div>
        </div>

        {/* Security Notice */}
        <div className="mt-12 p-6 bg-blue-50 border border-blue-200 rounded-xl">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-blue-900 mb-1">
                Security Reminder
              </p>
              <p style={{ fontSize: '0.875rem' }} className="text-blue-700">
                Never share your private keys. Your DID is public, but your credentials and proofs are private until you choose to share them.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}