import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { 
  Shield, 
  CheckCircle2, 
  XCircle, 
  ArrowLeft,
  Loader2,
  AlertCircle,
  FileCheck,
  Lock
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface VerificationPageProps {
  onBack?: () => void;
}

type VerificationStatus = "idle" | "verifying" | "valid" | "invalid";

interface VerificationResult {
  status: "valid" | "invalid";
  message: string;
  details: string[];
  timestamp?: string;
}

export function VerificationPage({ onBack }: VerificationPageProps) {
  const [cidInput, setCidInput] = useState("");
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>("idle");
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);

  const handleVerify = () => {
    if (!cidInput.trim()) {
      toast.error("Please enter a CID or verification request");
      return;
    }

    setVerificationStatus("verifying");
    setVerificationResult(null);

    // Simulate verification process
    setTimeout(() => {
      // Mock verification logic - 70% chance of valid for demo purposes
      const isValid = Math.random() > 0.3;
      
      if (isValid) {
        setVerificationResult({
          status: "valid",
          message: "Credential Successfully Verified",
          details: [
            "Cryptographic signature confirmed",
            "Issuer identity validated",
            "Credential has not been revoked",
            "Schema validation passed"
          ],
          timestamp: new Date().toISOString()
        });
        setVerificationStatus("valid");
        toast.success("Credential is valid!");
      } else {
        setVerificationResult({
          status: "invalid",
          message: "Verification Failed",
          details: [
            "Signature verification failed",
            "Credential may have been tampered with",
            "Unable to verify issuer authenticity"
          ],
          timestamp: new Date().toISOString()
        });
        setVerificationStatus("invalid");
        toast.error("Credential verification failed");
      }
    }, 2000);
  };

  const handleReset = () => {
    setCidInput("");
    setVerificationStatus("idle");
    setVerificationResult(null);
  };

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return "";
    const date = new Date(isoString);
    return date.toLocaleString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Navigation Header */}
      <nav className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-blue-600" />
              <span className="tracking-tight" style={{ fontSize: '1.25rem', fontWeight: '600' }}>
                IdentityVault
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12 max-w-4xl">
        {/* Back Button */}
        {onBack && (
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        )}

        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <FileCheck className="w-6 h-6 text-green-600" />
            </div>
            <h1 style={{ fontSize: '2.25rem', fontWeight: '700' }} className="text-gray-900">
              Verify Credential or Proof
            </h1>
          </div>
          <p className="text-gray-600 ml-15" style={{ fontSize: '1.125rem' }}>
            Validate verifiable credentials using IPFS CID or verification request ID
          </p>
        </div>

        {/* Input Card */}
        <Card className="mb-6 border-2 border-gray-200">
          <CardContent className="p-8">
            <label 
              htmlFor="cid-input"
              className="text-gray-900 mb-3 block" 
              style={{ fontSize: '0.875rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              Credential Identifier
            </label>
            
            <div className="space-y-4">
              <Input
                id="cid-input"
                type="text"
                value={cidInput}
                onChange={(e) => setCidInput(e.target.value)}
                placeholder="Paste IPFS CID or Verification Request Here (e.g., Qm...)"
                className="text-gray-900 h-12 px-4 border-2 border-gray-300 focus:border-green-500"
                style={{ fontSize: '1rem' }}
                disabled={verificationStatus === "verifying"}
              />
              
              <div className="flex gap-3">
                <Button
                  size="lg"
                  onClick={handleVerify}
                  disabled={!cidInput.trim() || verificationStatus === "verifying"}
                  className="bg-green-600 hover:bg-green-700 text-white px-8 disabled:opacity-50"
                >
                  {verificationStatus === "verifying" ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      <FileCheck className="w-5 h-5 mr-2" />
                      Verify
                    </>
                  )}
                </Button>
                
                {(verificationStatus === "valid" || verificationStatus === "invalid") && (
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={handleReset}
                    className="border-gray-300"
                  >
                    Verify Another
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Verification Result Card */}
        {verificationResult && (
          <Card 
            className={`mb-6 border-2 ${
              verificationResult.status === "valid" 
                ? "border-green-300 bg-gradient-to-br from-green-50 to-emerald-50" 
                : "border-red-300 bg-gradient-to-br from-red-50 to-rose-50"
            }`}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-4 mb-6">
                <div 
                  className={`w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 ${
                    verificationResult.status === "valid" 
                      ? "bg-green-100" 
                      : "bg-red-100"
                  }`}
                >
                  {verificationResult.status === "valid" ? (
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  ) : (
                    <XCircle className="w-8 h-8 text-red-600" />
                  )}
                </div>
                
                <div className="flex-1">
                  <h2 
                    style={{ fontSize: '1.75rem', fontWeight: '700' }} 
                    className={verificationResult.status === "valid" ? "text-green-900" : "text-red-900"}
                  >
                    {verificationResult.message}
                  </h2>
                  {verificationResult.timestamp && (
                    <p 
                      className={verificationResult.status === "valid" ? "text-green-700" : "text-red-700"}
                      style={{ fontSize: '0.875rem' }}
                    >
                      Verified on {formatTimestamp(verificationResult.timestamp)}
                    </p>
                  )}
                </div>
              </div>

              {/* Verification Details */}
              <div 
                className={`rounded-lg p-5 border ${
                  verificationResult.status === "valid" 
                    ? "bg-white border-green-200" 
                    : "bg-white border-red-200"
                }`}
              >
                <p 
                  style={{ fontSize: '0.875rem', fontWeight: '600' }} 
                  className="text-gray-900 mb-3 flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4" />
                  Verification Details
                </p>
                
                <ul className="space-y-2">
                  {verificationResult.details.map((detail, index) => (
                    <li 
                      key={index}
                      className={`flex items-start gap-2 ${
                        verificationResult.status === "valid" 
                          ? "text-green-800" 
                          : "text-red-800"
                      }`}
                      style={{ fontSize: '0.875rem' }}
                    >
                      {verificationResult.status === "valid" ? (
                        <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                      )}
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* CID Display */}
              <div className="mt-4 bg-white rounded-lg p-4 border border-gray-200">
                <p style={{ fontSize: '0.75rem', fontWeight: '600' }} className="text-gray-600 mb-2">
                  VERIFIED IDENTIFIER
                </p>
                <code 
                  className="text-gray-900 break-all"
                  style={{ fontSize: '0.875rem' }}
                >
                  {cidInput}
                </code>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-blue-900 mb-2">
                    How Verification Works
                  </p>
                  <ul className="space-y-1 text-blue-700" style={{ fontSize: '0.875rem' }}>
                    <li>• Retrieves credential from decentralized storage</li>
                    <li>• Validates cryptographic signatures</li>
                    <li>• Checks issuer's identity and authorization</li>
                    <li>• Verifies credential has not been revoked</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-purple-900 mb-2">
                    What You Can Verify
                  </p>
                  <ul className="space-y-1 text-purple-700" style={{ fontSize: '0.875rem' }}>
                    <li>• Verifiable Credentials (VCs)</li>
                    <li>• Verifiable Presentations (VPs)</li>
                    <li>• IPFS-stored documents</li>
                    <li>• Digital identity proofs</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Security Notice */}
        <Card className="mt-6 bg-gray-50 border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-gray-600 flex-shrink-0 mt-0.5" />
              <div>
                <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900 mb-1">
                  Privacy Notice
                </p>
                <p style={{ fontSize: '0.875rem' }} className="text-gray-600">
                  Verification is performed locally and does not share your credentials with third parties. 
                  Only the public information necessary for cryptographic verification is accessed.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
