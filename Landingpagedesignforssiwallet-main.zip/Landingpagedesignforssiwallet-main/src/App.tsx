import { Button } from "./components/ui/button";
import { Shield, Lock, Key } from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { DIDCreationForm } from "./components/DIDCreationForm";
import { WalletDashboard } from "./components/WalletDashboard";
import { IPFSUploadPage } from "./components/IPFSUploadPage";
import { VerificationPage } from "./components/VerificationPage";
import { Toaster } from "./components/ui/sonner";
import { useState } from "react";

type Screen = "landing" | "create-did" | "dashboard" | "ipfs-upload" | "verification";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("landing");
  const [userDID, setUserDID] = useState<string>("");

  const handleDIDCreated = (did: string) => {
    setUserDID(did);
    setCurrentScreen("dashboard");
  };

  if (currentScreen === "verification") {
    return (
      <>
        <VerificationPage onBack={() => setCurrentScreen("dashboard")} />
        <Toaster />
      </>
    );
  }

  if (currentScreen === "ipfs-upload") {
    return (
      <>
        <IPFSUploadPage onBack={() => setCurrentScreen("dashboard")} />
        <Toaster />
      </>
    );
  }

  if (currentScreen === "dashboard") {
    return (
      <>
        <WalletDashboard 
          did={userDID} 
          onLogout={() => setCurrentScreen("landing")}
          onNavigateToUpload={() => setCurrentScreen("ipfs-upload")}
          onNavigateToVerify={() => setCurrentScreen("verification")}
        />
        <Toaster />
      </>
    );
  }

  if (currentScreen === "create-did") {
    return (
      <>
        <DIDCreationForm 
          onBack={() => setCurrentScreen("landing")}
          onDIDCreated={handleDIDCreated}
        />
        <Toaster />
      </>
    );
  }

  return (
    <>
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Navigation */}
      <nav className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-blue-600" />
            <span className="tracking-tight" style={{ fontSize: '1.25rem', fontWeight: '600' }}>
              IdentityVault
            </span>
          </div>
          <Button variant="outline" className="border-blue-200 text-blue-700 hover:bg-blue-50">
            Sign In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8 max-w-2xl">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 rounded-full">
                <Lock className="w-4 h-4 text-blue-700" />
                <span style={{ fontSize: '0.875rem', fontWeight: '500' }} className="text-blue-700">
                  Self-Sovereign Identity
                </span>
              </div>
              
              <h1 
                className="tracking-tight text-gray-900" 
                style={{ fontSize: '3.5rem', fontWeight: '700', lineHeight: '1.1' }}
              >
                Your Digital Identity, <span className="text-blue-600">Secured</span>
              </h1>
              
              <p 
                className="text-gray-600 max-w-xl" 
                style={{ fontSize: '1.25rem', lineHeight: '1.75' }}
              >
                Take control of your personal data with decentralized identity management. 
                Private, secure, and entirely owned by you.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/30 px-8"
                onClick={() => setCurrentScreen("create-did")}
              >
                <Key className="w-5 h-5 mr-2" />
                Create Your Digital ID
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-gray-300 hover:bg-gray-50"
              >
                Learn More
              </Button>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-gray-600">Decentralized</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-gray-600">Privacy-First</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-gray-600">User-Controlled</span>
              </div>
            </div>
          </div>

          {/* Right Column - Hero Visual */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-blue-600/20">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1762279389045-110301edeecc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMG5ldHdvcmslMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MzAwNTkzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Decentralized network visualization"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/30 to-transparent mix-blend-multiply"></div>
            </div>

            {/* Floating Feature Cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-6 max-w-xs border border-gray-100">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 style={{ fontSize: '1rem', fontWeight: '600' }} className="text-gray-900">
                    Bank-Grade Security
                  </h3>
                  <p style={{ fontSize: '0.875rem' }} className="text-gray-600 mt-1">
                    Military-grade encryption protects your credentials
                  </p>
                </div>
              </div>
            </div>

            <div className="absolute -top-6 -right-6 bg-white rounded-2xl shadow-xl p-6 max-w-[200px] border border-gray-100">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6 text-green-600" />
                </div>
                <p style={{ fontSize: '0.875rem', fontWeight: '600' }} className="text-gray-900">
                  100% Private
                </p>
                <p style={{ fontSize: '0.75rem' }} className="text-gray-600 mt-1">
                  Zero knowledge proofs
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 pt-12 border-t border-gray-200">
          <p className="text-center text-gray-500 mb-8" style={{ fontSize: '0.875rem' }}>
            Trusted by leading organizations
          </p>
          <div className="flex flex-wrap items-center justify-center gap-12 opacity-60">
            <div className="text-gray-400" style={{ fontSize: '1.5rem', fontWeight: '700' }}>
              W3C Compliant
            </div>
            <div className="text-gray-400" style={{ fontSize: '1.5rem', fontWeight: '700' }}>
              Open Standards
            </div>
            <div className="text-gray-400" style={{ fontSize: '1.5rem', fontWeight: '700' }}>
              Blockchain Verified
            </div>
          </div>
        </div>
      </main>
    </div>
    <Toaster />
    </>
  );
}