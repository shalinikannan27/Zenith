
  # Landing Page Design for SSI Wallet

  This is a code bundle for Landing Page Design for SSI Wallet. The original project is available at https://www.figma.com/design/Tx9UMErSyxfON1OcWFafRe/Landing-Page-Design-for-SSI-Wallet.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  